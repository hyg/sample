/**
 * E2EE client for HPKE-based end-to-end encrypted messaging.
 * 
 * Compatible with Python's E2eeClient.
 * 
 * Supports:
 * - Session initiation (e2ee_init)
 * - Session acknowledgment (e2ee_ack)
 * - Encrypted message sending (e2ee_msg)
 * - Message decryption
 * - Session rekeying (e2ee_rekey)
 * - Error handling (e2ee_error)
 */

import { secp256k1 } from '@noble/curves/secp256k1';
import { x25519 } from '@noble/curves/ed25519';
import { sha256 } from '@noble/hashes/sha256';
import { hkdf } from '@noble/hashes/hkdf';
import { concatBytes, bytesToHex, hexToBytes } from '@noble/hashes/utils';
import { createCipheriv, createDecipheriv } from 'crypto';
import { hpkeSeal, hpkeOpen } from './hpke.js';
import { encodeBase64Url, decodeBase64Url, generateProof, verifyProof } from './utils/identity.js';

// Base64 helpers using Node.js Buffer
const bytesToBase64 = (bytes) => Buffer.from(bytes).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
const base64ToBytes = (base64) => {
    const padded = base64.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - base64.length % 4) % 4);
    return Uint8Array.from(Buffer.from(padded, 'base64'));
};

const SUPPORTED_E2EE_VERSION = '1.1';
const DEFAULT_EXPIRES = 3600; // 1 hour in seconds
const HPKE_SUITE = 'DHKEM-X25519/HKDF-SHA256/AES-128-GCM';
const PROOF_TYPE = 'EcdsaSecp256r1Signature2019';
const DEFAULT_MAX_SKIP = 256;
const DEFAULT_SKIP_KEY_TTL = 3600;

/**
 * E2EE Client class.
 */
export class E2eeClient {
    /**
     * Create E2EE client.
     * 
     * @param {string} localDid - Local DID identifier.
     * @param {string} signingPem - SECP256k1 signing private key PEM.
     * @param {string} x25519Pem - X25519 agreement private key PEM.
     */
    constructor(localDid, signingPem = null, x25519Pem = null) {
        this.localDid = localDid;
        this.signingKey = signingPem ? this._loadSigningKey(signingPem) : null;
        this.agreementKey = x25519Pem ? this._loadAgreementKey(x25519Pem) : null;
        this.sessions = new Map(); // peerDid -> session state
    }
    
    /**
     * Load signing private key from PEM.
     * @private
     */
    _loadSigningKey(pem) {
        // Extract raw bytes from PEM (simplified - in production use crypto library)
        const pemLines = pem.split('\n').filter(l => !l.startsWith('-----') && l.trim());
        const der = Buffer.from(pemLines.join(''), 'base64');
        
        // Find private key offset in PKCS#8
        let privOffset = -1;
        for (let i = 0; i < der.length - 2; i++) {
            if (der[i] === 0x04 && der[i + 1] === 0x20) {
                privOffset = i + 2;
                break;
            }
        }
        
        if (privOffset < 0) {
            throw new Error('Invalid signing key PEM');
        }
        
        return der.slice(privOffset, privOffset + 32);
    }
    
    /**
     * Load X25519 agreement private key from PEM.
     * @private
     */
    _loadAgreementKey(pem) {
        const pemLines = pem.split('\n').filter(l => !l.startsWith('-----') && l.trim());
        const der = Buffer.from(pemLines.join(''), 'base64');
        
        // X25519 private key is typically 32 bytes
        if (der.length >= 32) {
            // Try to find the 32-byte key
            for (let i = 0; i < der.length - 32; i++) {
                if (der[i] === 0x04 && der[i + 1] === 0x20) {
                    return der.slice(i + 2, i + 34);
                }
            }
            // Fallback: use last 32 bytes
            return der.slice(-32);
        }
        
        throw new Error('Invalid agreement key PEM');
    }
    
    /**
     * Generate new X25519 key pair for E2EE.
     * 
     * @returns {{publicKey: Uint8Array, privateKey: Uint8Array}}
     */
    static generateAgreementKey() {
        const privateKey = x25519.utils.randomPrivateKey();
        const publicKey = x25519.getPublicKey(privateKey);
        return { publicKey, privateKey };
    }
    
    /**
     * Initiate E2EE handshake with peer.
     * 
     * @param {string} peerDid - Peer DID identifier.
     * @returns {{msg_type: string, content: Object}} E2EE init message.
     */
    async initiateHandshake(peerDid) {
        // Generate new ephemeral key pair
        const { publicKey: ephemeralPk, privateKey: ephemeralSk } = E2eeClient.generateAgreementKey();
        
        // Create session ID
        const sessionId = bytesToHex(sha256(
            concatBytes(
                Buffer.from(this.localDid),
                Buffer.from(peerDid),
                ephemeralPk
            )
        )).slice(0, 32);
        
        // Initialize session state
        const session = {
            sessionId,
            peerDid,
            ephemeralSk,
            ephemeralPk,
            sendChainKey: null,
            recvChainKey: null,
            sendSeq: 0,
            recvSeq: 0,
            state: 'initiated'
        };
        
        this.sessions.set(peerDid, session);
        
        // Build e2ee_init content
        const content = {
            session_id: sessionId,
            e2ee_version: SUPPORTED_E2EE_VERSION,
            ephemeral_public_key: bytesToBase64(ephemeralPk),
            initiated_at: new Date().toISOString()
        };
        
        return {
            msg_type: 'e2ee_init',
            content
        };
    }
    
    /**
     * Process received E2EE handshake.
     * 
     * @param {Object} e2eeInit - e2ee_init message content.
     * @returns {{msg_type: string, content: Object}} E2EE ack message.
     */
    async processHandshake(e2eeInit) {
        const { session_id: sessionId, ephemeral_public_key: peerEphemeralPkB64, e2ee_version } = e2eeInit;

        if (e2ee_version !== SUPPORTED_E2EE_VERSION) {
            throw new Error(`Unsupported E2EE version: ${e2ee_version}`);
        }

        // Convert base64 to Uint8Array
        const peerEphemeralPk = Uint8Array.from(Buffer.from(peerEphemeralPkB64.replace(/-/g, '+').replace(/_/g, '/'), 'base64'));

        // Generate our ephemeral key pair
        const { publicKey: ephemeralPk, privateKey: ephemeralSk } = E2eeClient.generateAgreementKey();

        // Derive shared secret using X25519
        const sharedSecret = x25519.getSharedSecret(ephemeralSk, peerEphemeralPk);

        // Derive chain keys using simple SHA256 (compatible with Python implementation)
        const sendChainKey = sha256(concatBytes(sharedSecret, new TextEncoder().encode('anp-e2ee-init')));
        const recvChainKey = sha256(concatBytes(sharedSecret, new TextEncoder().encode('anp-e2ee-resp')));

        // Store session
        const session = {
            sessionId,
            ephemeralSk,
            ephemeralPk,
            sendChainKey,
            recvChainKey,
            sendSeq: 0,
            recvSeq: 0,
            state: 'active'
        };

        this.sessions.set(sessionId, session);

        // Build e2ee_ack content
        const content = {
            session_id: sessionId,
            e2ee_version: SUPPORTED_E2EE_VERSION,
            ephemeral_public_key: bytesToBase64(ephemeralPk),
            acknowledged_at: new Date().toISOString()
        };
        
        return {
            msg_type: 'e2ee_ack',
            content
        };
    }
    
    /**
     * Encrypt message for peer.
     * 
     * @param {string} peerDid - Peer DID identifier.
     * @param {string} plaintext - Plaintext message.
     * @param {string} originalType - Original message type (e.g., 'text').
     * @returns {{msg_type: string, content: Object}} Encrypted message.
     */
    async encryptMessage(peerDid, plaintext, originalType = 'text') {
        const session = this.sessions.get(peerDid);
        
        if (!session || session.state !== 'active') {
            throw new Error(`No active E2EE session with ${peerDid}`);
        }
        
        // Derive message key from chain key
        const seqBytes = Buffer.alloc(8);
        seqBytes.writeBigUInt64BE(BigInt(session.sendSeq), 0);
        
        const msgKey = Buffer.from(
            sha256(concatBytes(Buffer.from('msg'), seqBytes, session.sendChainKey))
        );
        
        const newChainKey = Buffer.from(sha256(concatBytes(Buffer.from('ck'), session.sendChainKey)));
        session.sendChainKey = newChainKey;
        
        const encKey = Buffer.from(sha256(concatBytes(Buffer.from('key'), msgKey))).slice(0, 16);
        const nonce = Buffer.from(sha256(concatBytes(Buffer.from('nonce'), msgKey))).slice(0, 12);
        
        // Encrypt with AES-CTR using Node.js crypto
        const cipher = createCipheriv('aes-128-ctr', encKey, nonce);
        const plaintextBytes = Buffer.from(plaintext, 'utf-8');
        const encrypted = Buffer.concat([cipher.update(plaintextBytes), cipher.final()]);
        const ciphertext = Buffer.from(encrypted);
        
        session.sendSeq++;
        
        // Build encrypted content
        const content = {
            session_id: session.sessionId,
            seq: session.sendSeq - 1,
            ciphertext: bytesToBase64(ciphertext),
            original_type: originalType,
            encrypted_at: new Date().toISOString()
        };
        
        return {
            msg_type: 'e2ee_msg',
            content
        };
    }
    
    /**
     * Process E2EE protocol message (init/rekey/error).
     * 
     * @param {string} msgType - Message type (e2ee_init/e2ee_rekey/e2ee_error).
     * @param {Object} content - Message content dict.
     * @returns {Promise<Array<[string, Object]>>} List of messages to send (usually empty for HPKE).
     */
    async process_e2ee_message(msgType, content) {
        if (msgType === 'e2ee_ack') {
            return await this._handleAck(content);
        }
        
        // For init/rekey/error, just validate and process
        if (msgType === 'e2ee_init') {
            return await this._handleInit(content);
        } else if (msgType === 'e2ee_rekey') {
            return await this._handleRekey(content);
        } else if (msgType === 'e2ee_error') {
            return await this._handleError(content);
        } else if (msgType === 'e2ee_msg') {
            console.warn('process_e2ee_message does not handle encrypted messages, use decrypt_message instead');
            return [];
        } else {
            console.warn(`Unhandled E2EE message subtype: ${msgType}`);
            return [];
        }
    }
    
    /**
     * Decrypt received message (Python-style).
     * 
     * @param {Object} content - e2ee_msg content.
     * @returns {[string, string]} Tuple of [original_type, plaintext].
     */
    async decrypt_message(content) {
        const result = await this.decryptMessage(content);
        return [result.original_type, result.plaintext];
    }
    
    /**
     * Decrypt received message.
     * 
     * @param {Object} e2eeMsg - e2ee_msg content.
     * @returns {{plaintext: string, original_type: string}} Decrypted message.
     */
    async decryptMessage(e2eeMsg) {
        const { session_id: sessionId, seq, ciphertext: ciphertextB64 } = e2eeMsg;
        
        let session = this.sessions.get(sessionId);
        
        if (!session) {
            throw new Error(`E2EE session not found: ${sessionId}`);
        }
        
        if (seq < session.recvSeq) {
            throw new Error(`Message seq ${seq} is older than expected ${session.recvSeq}`);
        }
        
        const ciphertext = base64ToBytes(ciphertextB64);
        
        // Derive message key for this sequence number
        const seqBytes = Buffer.alloc(8);
        seqBytes.writeBigUInt64BE(BigInt(seq), 0);
        
        // Derive chain key up to this sequence
        let chainKey = session.recvChainKey;
        for (let i = session.recvSeq; i < seq; i++) {
            chainKey = Buffer.from(sha256(concatBytes(Buffer.from('ck'), chainKey)));
        }
        
        const msgKey = Buffer.from(
            sha256(concatBytes(Buffer.from('msg'), seqBytes, chainKey))
        );
        
        const encKey = Buffer.from(sha256(concatBytes(Buffer.from('key'), msgKey))).slice(0, 16);
        const nonce = Buffer.from(sha256(concatBytes(Buffer.from('nonce'), msgKey))).slice(0, 12);
        
        // Decrypt with AES-CTR using Node.js crypto
        const decipher = createDecipheriv('aes-128-ctr', encKey, nonce);
        const ciphertextBytes = Uint8Array.from(ciphertext);
        const decrypted = Buffer.concat([decipher.update(Buffer.from(ciphertextBytes)), decipher.final()]);
        const plaintextBytes = Buffer.from(decrypted);
        
        session.recvSeq = seq + 1;
        session.recvChainKey = chainKey;
        
        return {
            plaintext: plaintextBytes.toString('utf-8'),
            original_type: e2eeMsg.original_type || 'text'
        };
    }
    
    /**
     * Export session state for persistence.
     * 
     * @returns {Object} Serializable session state.
     */
    exportState() {
        const sessions = {};
        for (const [key, session] of this.sessions.entries()) {
            sessions[key] = {
                ...session,
                ephemeralSk: bytesToHex(session.ephemeralSk),
                ephemeralPk: bytesToHex(session.ephemeralPk),
                sendChainKey: session.sendChainKey ? bytesToHex(session.sendChainKey) : null,
                recvChainKey: session.recvChainKey ? bytesToHex(session.recvChainKey) : null
            };
        }
        
        return {
            local_did: this.localDid,
            sessions
        };
    }
    
    /**
     * Import session state from persistence.
     * 
     * @param {Object} state - Serialized session state.
     * @returns {E2eeClient} E2EE client with restored sessions.
     */
    static fromState(state) {
        const client = new E2eeClient(state.local_did);
        
        for (const [key, session] of Object.entries(state.sessions || {})) {
            client.sessions.set(key, {
                ...session,
                ephemeralSk: hexToBytes(session.ephemeralSk),
                ephemeralPk: hexToBytes(session.ephemeralPk),
                sendChainKey: session.sendChainKey ? hexToBytes(session.sendChainKey) : null,
                recvChainKey: session.recvChainKey ? hexToBytes(session.recvChainKey) : null
            });
        }
        
        return client;
    }
    
    /**
     * Handle e2ee_init message.
     * @param {Object} content - Message content
     * @returns {Promise<Array<[string, Object]>>} Response messages
     */
    async _handleInit(content) {
        // Process handshake and return e2ee_ack
        const result = await this.processHandshake(content);
        return [[result.msg_type, result.content]];
    }
    
    /**
     * Handle e2ee_rekey message.
     * @param {Object} content - Message content
     * @returns {Promise<Array<[string, Object]>>} Response messages
     */
    async _handleRekey(content) {
        // For HPKE, rekey is handled similarly to init
        const result = await this.processHandshake(content);
        return [[result.msg_type, result.content]];
    }
    
    /**
     * Handle e2ee_error message.
     * @param {Object} content - Message content
     * @returns {Promise<Array<[string, Object]>>} Empty list
     */
    async _handleError(content) {
        // e2ee_error is informational, no response needed
        console.log(`E2EE error received: ${content.error_code}`);
        return [];
    }
    
    /**
     * Handle e2ee_ack message.
     * @param {Object} content - Message content
     * @returns {Promise<Array<[string, Object]>>} Empty list
     */
    async _handleAck(content) {
        const sessionId = content.session_id;
        const session = this.sessions.get(sessionId);
        if (session) {
            session.state = 'active';
            console.log(`E2EE session confirmed: ${sessionId}`);
        }
        return [];
    }
    
    /**
     * Check if session ID exists and is active.
     * @param {string|null} sessionId - Session ID
     * @returns {boolean} True if session exists
     */
    has_session_id(sessionId) {
        if (!sessionId) {
            return false;
        }
        const session = this.sessions.get(sessionId);
        return session !== undefined && session.state === 'active';
    }
}

// Define SessionState and SeqManager for e2ee_session.js
export const SessionState = {
    IDLE: 'IDLE',
    ACTIVE: 'ACTIVE'
};

export class SeqManager {
    constructor({ mode = 'STRICT', maxSkip = 256 } = {}) {
        this.mode = mode;
        this.sendSeq = 0;
        this.recvSeq = 0;
        this.maxSkip = maxSkip;
        this.usedSeqs = new Set();
    }

    nextSendSeq() {
        return this.sendSeq++;
    }

    currentSendSeq() {
        return this.sendSeq;
    }

    validateRecvSeq(seq) {
        if (this.mode === 'STRICT') {
            // In STRICT mode, we expect seq to be exactly recvSeq
            // But also need to check if it's already used (replay)
            if (this.usedSeqs.has(seq)) {
                return false; // Replay attack
            }
            return seq === this.recvSeq;
        } else if (this.mode === 'WINDOW') {
            // In WINDOW mode, seq must be within window and not already used
            if (this.usedSeqs.has(seq)) {
                return false; // Replay attack
            }
            return seq >= this.recvSeq && seq < this.recvSeq + this.maxSkip;
        }
        return false;
    }

    markSeqUsed(seq) {
        this.usedSeqs.add(seq);
        // In STRICT mode, advance recvSeq if this is the expected sequence
        if (this.mode === 'STRICT' && seq === this.recvSeq) {
            this.recvSeq++;
        }
    }

    advanceRecvTo(seq) {
        if (seq >= this.recvSeq) {
            this.recvSeq = seq + 1;
        }
    }

    next() {
        return this.sendSeq++;
    }

    current() {
        return this.sendSeq;
    }
}

export const SeqMode = {
    STRICT: 'STRICT',
    WINDOW: 'WINDOW'
};

/**
 * Derive chain keys from root seed.
 * @param {Buffer} rootSeed - Root seed (32 bytes)
 * @returns {{initChainKey: Buffer, respChainKey: Buffer}}
 */
export function deriveChainKeys(rootSeed) {
    // Use HKDF to derive two chain keys
    const salt = Buffer.alloc(32); // Zero salt
    const info = Buffer.from('anp-e2ee-chain-keys');
    
    const ikm = rootSeed;
    
    // Derive 64 bytes (2 * 32)
    const derived = hkdf(sha256, ikm, salt, info, 64);
    
    const initChainKey = derived.slice(0, 32);
    const respChainKey = derived.slice(32, 64);
    
    return { initChainKey, respChainKey };
}

/**
 * Derive message key from chain key and sequence number.
 * @param {Buffer} chainKey - Chain key
 * @param {number} seq - Sequence number
 * @returns {{encKey: Buffer, nonce: Buffer, newChainKey: Buffer}}
 */
export function deriveMessageKey(chainKey, seq) {
    const seqBytes = Buffer.alloc(8);
    seqBytes.writeBigUInt64BE(BigInt(seq), 0);
    
    // Derive message key
    const msgKey = sha256(concatBytes(Buffer.from('msg'), seqBytes, chainKey));
    
    // Derive new chain key
    const newChainKey = sha256(concatBytes(Buffer.from('ck'), chainKey));
    
    // Derive encryption key and nonce
    const encKey = sha256(concatBytes(Buffer.from('key'), msgKey)).slice(0, 16);
    const nonce = sha256(concatBytes(Buffer.from('nonce'), msgKey)).slice(0, 12);
    
    return {
        encKey: Buffer.from(encKey),
        nonce: Buffer.from(nonce),
        newChainKey: Buffer.from(newChainKey)
    };
}

/**
 * Determine direction of message (initiator or responder).
 * @param {string} localDid - Local DID
 * @param {string} peerDid - Peer DID
 * @returns {'initiator' | 'responder'}
 */
export function determineDirection(localDid, peerDid) {
    return localDid < peerDid ? 'initiator' : 'responder';
}

/**
 * Assign chain keys based on direction.
 * @param {Object} params
 * @returns {{sendChainKey: Buffer, recvChainKey: Buffer}}
 */
export function assignChainKeys({ initChainKey, respChainKey, direction }) {
    if (direction === 'initiator') {
        return {
            sendChainKey: initChainKey,
            recvChainKey: respChainKey
        };
    } else {
        return {
            sendChainKey: respChainKey,
            recvChainKey: initChainKey
        };
    }
}

export { 
    SUPPORTED_E2EE_VERSION, 
    DEFAULT_EXPIRES,
    HPKE_SUITE,
    PROOF_TYPE,
    DEFAULT_MAX_SKIP,
    DEFAULT_SKIP_KEY_TTL,
    hpkeSeal,
    hpkeOpen,
    encodeBase64Url as base64UrlEncode,
    decodeBase64Url as base64UrlDecode,
    generateProof,
    verifyProof
};
