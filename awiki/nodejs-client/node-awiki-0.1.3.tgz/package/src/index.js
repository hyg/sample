/**
 * awiki-sdk: General SDK for DID identity creation, WBA authentication, JWT acquisition,
 * Handle registration, and WebSocket client.
 * 
 * Centralizes export of all public interfaces.
 * 
 * @module index
 */

// Config
import { createSDKConfig } from './utils/config.js';
export { createSDKConfig };

// Identity
import {
    createIdentity,
    generateProof,
    generateE2eeKeys,
    encodeBase64Url,
    decodeBase64Url,
    publicKeyToJwk,
    privateKeyToPem,
    publicKeyToPem,
    loadPrivateKey
} from './utils/identity.js';
export {
    createIdentity,
    generateProof,
    generateE2eeKeys,
    encodeBase64Url,
    decodeBase64Url,
    publicKeyToJwk,
    privateKeyToPem,
    publicKeyToPem,
    loadPrivateKey
};

// Auth
import {
    DIDWbaAuthHeader,
    generateWbaAuthHeader,
    registerDid,
    getJwtViaWba,
    createAuthenticatedIdentity
} from './utils/auth.js';
export {
    DIDWbaAuthHeader,
    generateWbaAuthHeader,
    registerDid,
    getJwtViaWba,
    createAuthenticatedIdentity
};

// Client
import {
    createUserServiceClient,
    createMoltMessageClient
} from './utils/client.js';
export {
    createUserServiceClient,
    createMoltMessageClient
};

// RPC
import {
    JsonRpcError,
    rpcCall,
    authenticatedRpcCall
} from './utils/rpc.js';
export {
    JsonRpcError,
    rpcCall,
    authenticatedRpcCall
};

// Resolve
import { resolveToDid } from './utils/resolve.js';
export { resolveToDid };

// Credential Store
import {
    saveIdentity,
    loadIdentity,
    listIdentities,
    deleteIdentity,
    updateJwt,
    extractAuthCredentials,
    createAuthenticator
} from './credential_store.js';
export {
    saveIdentity,
    loadIdentity,
    listIdentities,
    deleteIdentity,
    updateJwt,
    extractAuthCredentials,
    createAuthenticator
};

// E2EE
import {
    HPKE_SUITE,
    PROOF_TYPE,
    DEFAULT_EXPIRES,
    DEFAULT_MAX_SKIP,
    DEFAULT_SKIP_KEY_TTL,
    SeqMode,
    SessionState,
    SeqManager,
    verifyProof,
    hpkeSeal,
    hpkeOpen,
    deriveChainKeys,
    determineDirection,
    assignChainKeys,
    deriveMessageKey,
    base64UrlEncode,
    base64UrlDecode
} from './e2ee.js';
export {
    HPKE_SUITE,
    PROOF_TYPE,
    DEFAULT_EXPIRES,
    DEFAULT_MAX_SKIP,
    DEFAULT_SKIP_KEY_TTL,
    SeqMode,
    SessionState,
    SeqManager,
    verifyProof,
    hpkeSeal,
    hpkeOpen,
    deriveChainKeys,
    determineDirection,
    assignChainKeys,
    deriveMessageKey,
    base64UrlEncode,
    base64UrlDecode
};

import {
    E2eeHpkeSession,
    exportSession,
    importSession
} from './e2ee_session.js';
export {
    E2eeHpkeSession,
    exportSession,
    importSession
};

import {
    HpkeKeyManager
} from './e2ee_key_manager.js';
export {
    HpkeKeyManager
};

// E2EE Store
import {
    saveE2eeState,
    loadE2eeState,
    deleteE2eeState
} from './e2ee_store.js';
export {
    saveE2eeState,
    loadE2eeState,
    deleteE2eeState
};

export default {
    // Config
    createSDKConfig,
    
    // Identity
    createIdentity,
    generateProof,
    generateE2eeKeys,
    encodeBase64Url,
    decodeBase64Url,
    publicKeyToJwk,
    privateKeyToPem,
    publicKeyToPem,
    loadPrivateKey,
    
    // Auth
    DIDWbaAuthHeader,
    generateWbaAuthHeader,
    registerDid,
    getJwtViaWba,
    createAuthenticatedIdentity,
    
    // Client
    createUserServiceClient,
    createMoltMessageClient,
    
    // RPC
    JsonRpcError,
    rpcCall,
    authenticatedRpcCall,
    
    // Resolve
    resolveToDid,
    
    // Credential Store
    saveIdentity,
    loadIdentity,
    listIdentities,
    deleteIdentity,
    updateJwt,
    extractAuthCredentials,
    createAuthenticator,
    
    // E2EE
    HPKE_SUITE,
    PROOF_TYPE,
    DEFAULT_EXPIRES,
    SeqMode,
    SessionState,
    SeqManager,
    E2eeHpkeSession,
    HpkeKeyManager,
    saveE2eeState,
    loadE2eeState,
    deleteE2eeState
};
