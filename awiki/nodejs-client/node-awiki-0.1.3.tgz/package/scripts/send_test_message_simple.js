#!/usr/bin/env node

/**
 * Send a test message to a specific DID using direct JWT.
 * 
 * Usage:
 *   set NODE_AWIKI_DEBUG=true
 *   node scripts/send_test_message_simple.js
 */

import fs from 'fs';
import path from 'path';
import axios from 'axios';
import { loadIdentity } from '../src/credential_store.js';

// Target DID
const TARGET_DID = 'did:wba:awiki.ai:user:k1_h0MSe1gi2PDdhTWVIqraR6Vu3Kn62mtZbXhilDa5LQc';

// Sender (use default which was just created)
const SENDER_NAME = 'default';

function getCredentialsDir() {
    if (process.env.NODE_AWIKI_DEBUG === 'true') {
        return path.join(process.cwd(), '.credentials');
    } else {
        return path.join(
            process.env.USERPROFILE || process.env.HOME,
            '.openclaw',
            'credentials',
            'awiki-agent-id-message'
        );
    }
}

// loadIdentity function is now imported from credential_store.js

async function sendTestMessage() {
    console.log('='.repeat(60));
    console.log('Send Test Message');
    console.log('='.repeat(60));
    console.log(`Target DID: ${TARGET_DID}`);
    console.log(`Sender: ${SENDER_NAME}`);
    console.log('='.repeat(60));
    
    // Load sender identity
    console.log(`\nLoading sender identity: ${SENDER_NAME}...`);
    
    const identity = loadIdentity(SENDER_NAME);
    
    if (!identity) {
        console.log(` Identity '${SENDER_NAME}' not found.`);
        console.log(`\nCreate it with:`);
        console.log(`  set NODE_AWIKI_DEBUG=true`);
        console.log(`  node scripts/setup_identity.js --name ${SENDER_NAME} --agent`);
        return;
    }
    
    console.log(` Loaded: ${identity.did.substring(0, 60)}...`);
    
    // Check JWT
    const jwt = identity.jwt_token;
    if (!jwt) {
        console.log(` No JWT token found.`);
        return;
    }
    
    // Check JWT expiration
    try {
        const jwtParts = jwt.split('.');
        const payload = JSON.parse(Buffer.from(jwtParts[1], 'base64').toString());
        const expTime = new Date(payload.exp * 1000);
        const now = new Date();
        const expiresIn = Math.round((expTime - now) / 1000 / 60);
        
        if (expTime < now) {
            console.log(` JWT EXPIRED at ${expTime.toISOString()}`);
            console.log(`\nRefresh with:`);
            console.log(`  node scripts/setup_identity.js --load ${SENDER_NAME}`);
            return;
        }
        
        console.log(` JWT valid for ${expiresIn} minutes`);
    } catch (e) {
        console.log(`⚠ Could not check JWT expiration: ${e.message}`);
    }
    
    // Send message
    console.log(`\nSending test message...`);
    
    const messageContent = `Test message from Node.js CLI @ ${new Date().toISOString()}`;
    
    try {
        const response = await axios.post(
            'https://awiki.ai/message/rpc',
            {
                jsonrpc: '2.0',
                method: 'send',
                params: {
                    sender_did: identity.did,
                    receiver_did: TARGET_DID,
                    content: messageContent,
                    type: 'text',
                    client_msg_id: `test_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
                },
                id: 1
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${jwt}`
                }
            }
        );
        
        const result = response.data;
        
        if (result.error) {
            console.log(`\n Failed: ${result.error.message}`);
            return;
        }
        
        console.log(`\n✅ Message sent successfully!`);
        console.log(`   Server Seq: ${result.result.server_seq}`);
        console.log(`   Message ID: ${result.result.id}`);
        console.log(`   Content: ${messageContent}`);
        
    } catch (e) {
        console.log(`\n Failed: ${e.message}`);
        
        if (e.response && e.response.status === 401) {
            console.log(`\n   JWT expired. Refresh with:`);
            console.log(`   node scripts/setup_identity.js --load ${SENDER_NAME}`);
        }
        
        throw e;
    }
    
    console.log('\n' + '='.repeat(60));
    console.log('Done');
    console.log('='.repeat(60));
}

// Run
sendTestMessage().catch(console.error);
