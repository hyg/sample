#!/usr/bin/env node

/**
 * Send a test message to a specific DID.
 * 
 * Usage:
 *   node scripts/send_test_message.js
 */

import { loadIdentity } from '../src/credential_store.js';
import { createSDKConfig } from '../src/utils/config.js';
import { createMoltMessageClient } from '../src/utils/client.js';
import { authenticatedRpcCall } from '../src/utils/rpc.js';

// Target DID
const TARGET_DID = 'did:wba:awiki.ai:user:k1_h0MSe1gi2PDdhTWVIqraR6Vu3Kn62mtZbXhilDa5LQc';

async function sendTestMessage() {
    console.log('='.repeat(60));
    console.log('Send Test Message');
    console.log('='.repeat(60));
    console.log(`Target DID: ${TARGET_DID}`);
    console.log('='.repeat(60));
    
    // Load sender identity (use MsgTest1 which has valid JWT)
    const senderName = 'MsgTest1';
    console.log(`\nLoading sender identity: ${senderName}...`);
    
    const identity = loadIdentity(senderName);
    
    if (!identity) {
        console.log(`❌ Identity '${senderName}' not found.`);
        console.log(`\nCreate it with:`);
        console.log(`  set NODE_AWIKI_DEBUG=true`);
        console.log(`  node scripts/setup_identity.js --name ${senderName} --agent`);
        return;
    }
    
    console.log(`✅ Loaded: ${identity.did.substring(0, 60)}...`);
    
    // Check JWT
    if (!identity.jwt_token) {
        console.log(`❌ No JWT token found.`);
        return;
    }
    
    // Check JWT expiration
    try {
        const jwtParts = identity.jwt_token.split('.');
        const payload = JSON.parse(Buffer.from(jwtParts[1], 'base64').toString());
        const expTime = new Date(payload.exp * 1000);
        const now = new Date();
        const expiresIn = Math.round((expTime - now) / 1000 / 60);
        
        if (expTime < now) {
            console.log(`❌ JWT EXPIRED at ${expTime.toISOString()}`);
            console.log(`\nRefresh with:`);
            console.log(`  node scripts/setup_identity.js --load ${senderName}`);
            return;
        }
        
        console.log(`✅ JWT valid for ${expiresIn} minutes`);
    } catch (e) {
        console.log(`⚠️ Could not check JWT expiration: ${e.message}`);
    }
    
    // Send message
    console.log(`\nSending test message...`);
    
    const config = createSDKConfig();
    const client = createMoltMessageClient(config);
    
    const messageContent = `Test message from Node.js CLI @ ${new Date().toISOString()}`;
    
    try {
        const result = await authenticatedRpcCall(
            client,
            '/message/rpc',
            'send',
            {
                sender_did: identity.did,
                receiver_did: TARGET_DID,
                content: messageContent,
                type: 'text',
                client_msg_id: `test_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
            },
            1
        );
        
        console.log(`\n✅ Message sent successfully!`);
        console.log(`   Server Seq: ${result.server_seq}`);
        console.log(`   Message ID: ${result.id}`);
        console.log(`   Content: ${messageContent}`);
        
    } catch (e) {
        console.log(`\n❌ Failed to send message: ${e.message}`);
        
        if (e.message.includes('401')) {
            console.log(`\n   JWT expired. Refresh with:`);
            console.log(`   node scripts/setup_identity.js --load ${senderName}`);
        }
        
        throw e;
    }
    
    console.log('\n' + '='.repeat(60));
    console.log('Done');
    console.log('='.repeat(60));
}

// Run
sendTestMessage().catch(console.error);
