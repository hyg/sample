/**
 * SDK Configuration.
 *
 * Compatible with Python's scripts/utils/config.py.
 */

import path from 'path';
import { fileURLToPath } from 'url';

const SKILL_NAME = "awiki-agent-id-message";

/**
 * 检测运行模式
 * @private
 * @returns {string} 'debug' 或 'normal'
 */
function detectMode() {
    // 检查命令行参数
    const args = process.argv.slice(2);
    if (args.includes('--debug') || args.includes('-d')) {
        return 'debug';
    }
    if (args.includes('--normal') || args.includes('-n')) {
        return 'normal';
    }
    
    // 检查环境变量
    if (process.env.NODE_AWIKI_MODE === 'debug') {
        return 'debug';
    }
    if (process.env.NODE_AWIKI_MODE === 'normal') {
        return 'normal';
    }
    
    // 默认模式: 根据当前目录判断
    const currentDir = process.cwd();
    if (currentDir.includes('nodejs-client')) {
        return 'debug';
    }
    
    return 'normal';
}

// 当前模式
const MODE = detectMode();

/**
 * Get credentials directory.
 * @private
 * @returns {string} Credentials directory path
 */
function getCredentialsDir() {
    if (MODE === 'debug') {
        // 调试模式: 使用本项目文件夹内的路径
        const __dirname = path.dirname(fileURLToPath(import.meta.url));
        return path.join(__dirname, '..', '..', '.credentials');
    } else {
        // 正常模式: 使用 Python 版本相同的路径
        // Python 版本使用 C:\Users\hyg\.openclaw\credentials\awiki-agent-id-message
        return 'C:\\Users\\hyg\\.openclaw\\credentials\\awiki-agent-id-message';
    }
}

/**
 * Get data directory.
 * @private
 * @returns {string} Data directory path
 */
function getDataDir() {
    if (MODE === 'debug') {
        // 调试模式: 使用本项目文件夹内的路径
        const __dirname = path.dirname(fileURLToPath(import.meta.url));
        return path.join(__dirname, '..', '..', '.data');
    } else {
        // 正常模式: 使用 Python 版本相同的路径
        const home = process.env.HOME || process.env.USERPROFILE || process.env.HOMEPATH;
        
        // Priority 1: AWIKI_DATA_DIR env (direct full path override)
        if (process.env.AWIKI_DATA_DIR) {
            return process.env.AWIKI_DATA_DIR;
        }
        
        // Priority 2: AWIKI_WORKSPACE env / data / <skill>
        if (process.env.AWIKI_WORKSPACE) {
            return path.join(process.env.AWIKI_WORKSPACE, 'data', SKILL_NAME);
        }
        
        // Priority 3: ~/.openclaw/workspace / data / <skill>
        return path.join(home, '.openclaw', 'workspace', 'data', SKILL_NAME);
    }
}

/**
 * Get current mode.
 * @returns {string} Current mode ('debug' or 'normal')
 */
export function getMode() {
    return MODE;
}

/**
 * Create SDK configuration.
 * @returns {Object} SDK config object
 */
export function createSDKConfig() {
    return {
        user_service_url: 'https://awiki.ai',
        did_domain: 'awiki.ai',
        credentials_dir: getCredentialsDir(),
        data_dir: getDataDir(),
        mode: MODE
    };
}

export default {
    createSDKConfig
};
