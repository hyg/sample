#!/usr/bin/env node

/**
 * Multi-account message test for debugging JWT and messaging issues.
 * 
 * Usage:
 *   # Debug mode (uses local .credentials/)
 *   NODE_AWIKI_DEBUG=true node scripts/test_multi_account_messages.js
 * 
 *   # Production mode (uses system credentials)
 *   node scripts/test_multi_account_messages.js
 */

import { loadIdentity, saveIdentity } from '../src/credential_store.js';
import { createSDKConfig } from '../src/utils/config.js';
import { createMoltMessageClient, createUserServiceClient } from '../src/utils/client.js';
import { authenticatedRpcCall } from '../src/utils/rpc.js';
import { getJwtViaWba } from '../src/auth.js';

// Test accounts - using existing accounts
const TEST_ACCOUNTS = [
    { name: 'nodeagentfixed', did: null, jwt: null },
    { name: 'nodetest1', did: null, jwt: null },
    { name: 'MsgTest1', did: null, jwt: null }
];

async function loadOrCreateAccount(account) {
    console.log(`\n=== Loading account: ${account.name} ===`);
    
    let identity = loadIdentity(account.name);
    
    if (!identity) {
        console.log(`Account ${account.name} not found, creating new one...`);
        // For now, just report that account doesn't exist
        console.log(`Please create account ${account.name} first using:`);
        console.log(`  node scripts/setup_identity.js --name ${account.name} --agent`);
        return false;
    }
    
    account.did = identity.did;
    account.jwt = identity.jwt_token;
    
    console.log(`DID: ${identity.did.substring(0, 60)}...`);
    console.log(`JWT: ${identity.jwt_token ? identity.jwt_token.substring(0, 50) + '...' : 'NONE'}`);
    
    // Check JWT expiration
    if (identity.jwt_token) {
        try {
            const jwtParts = identity.jwt_token.split('.');
            const payload = JSON.parse(Buffer.from(jwtParts[1], 'base64').toString());
            const expTime = new Date(payload.exp * 1000);
            const now = new Date();
            const isExpired = expTime < now;
            const expiresIn = Math.round((expTime - now) / 1000 / 60);
            
            console.log(`JWT Expires: ${expTime.toISOString()}`);
            console.log(`JWT Status: ${isExpired ? 'EXPIRED' : `Valid (${expiresIn} minutes left)`}`);
        } catch (e) {
            console.log(`JWT Status: Could not parse - ${e.message}`);
        }
    }
    
    return true;
}

async function refreshJwt(account) {
    console.log(`\n=== Refreshing JWT for ${account.name} ===`);
    
    const identity = loadIdentity(account.name);
    if (!identity) {
        console.log(`Cannot refresh JWT: Account not found`);
        return false;
    }
    
    try {
        const config = createSDKConfig();
        const newJwt = await getJwtViaWba(
            config.user_service_url,
            identity.did_document,
            Buffer.from(identity.private_key_hex, 'hex'),
            'awiki.ai'
        );
        
        // Save new JWT
        identity.jwt_token = newJwt;
        saveIdentity({
            ...identity,
            name: account.name
        });
        
        account.jwt = newJwt;
        console.log(`JWT refreshed successfully!`);
        return true;
    } catch (e) {
        console.log(`Failed to refresh JWT: ${e.message}`);
        return false;
    }
}

async function sendMessage(from, to, content) {
    console.log(`\n=== Sending message: ${from.name} -> ${to.name} ===`);
    
    const config = createSDKConfig();
    const client = createMoltMessageClient(config);
    
    try {
        const result = await authenticatedRpcCall(
            client,
            '/message/rpc',
            'send',
            {
                sender_did: from.did,
                receiver_did: to.did,
                content: content,
                type: 'text',
                client_msg_id: `test_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`
            },
            1,
            { credentialName: from.name }
        );
        
        console.log(`Message sent successfully!`);
        console.log(`  Server Seq: ${result.server_seq}`);
        console.log(`  Message ID: ${result.id}`);
        return result;
    } catch (e) {
        console.log(`Failed to send message: ${e.message}`);
        if (e.message.includes('401')) {
            console.log(`  → JWT may be expired, trying to refresh...`);
            if (await refreshJwt(from)) {
                console.log(`  → Retrying with new JWT...`);
                return sendMessage(from, to, content);
            }
        }
        throw e;
    }
}

async function checkInbox(account) {
    console.log(`\n=== Checking inbox for ${account.name} ===`);
    
    const config = createSDKConfig();
    const client = createMoltMessageClient(config);
    
    try {
        const result = await authenticatedRpcCall(
            client,
            '/message/rpc',
            'get_inbox',
            {
                user_did: account.did,
                limit: 10
            },
            1,
            { credentialName: account.name }
        );
        
        const messages = result.messages || [];
        console.log(`Inbox: ${messages.length} message(s)`);
        
        for (const msg of messages) {
            const from = msg.sender_name || msg.sender_did.substring(0, 30);
            const content = msg.content.substring(0, 50);
            const read = msg.is_read ? 'Read' : 'Unread';
            console.log(`  - [${read}] From ${from}: ${content}`);
        }
        
        return messages;
    } catch (e) {
        console.log(`Failed to check inbox: ${e.message}`);
        if (e.message.includes('401')) {
            console.log(`  → JWT may be expired`);
        }
        throw e;
    }
}

async function runTests() {
    console.log('='.repeat(60));
    console.log('Multi-Account Message Test');
    console.log('='.repeat(60));
    console.log(`NODE_AWIKI_DEBUG: ${process.env.NODE_AWIKI_DEBUG}`);
    console.log(`NODE_ENV: ${process.env.NODE_ENV}`);
    console.log(`Mode: ${process.env.NODE_AWIKI_DEBUG === 'true' ? 'DEBUG (local .credentials/)' : 'PRODUCTION (system credentials)'}`);
    console.log(`Credentials Dir: ${process.env.NODE_AWIKI_DEBUG === 'true' ? './.credentials/' : 'C:\\Users\\hyg\\.openclaw\\credentials\\awiki-agent-id-message\\'}`);
    console.log('='.repeat(60));
    
    // Load accounts
    const loadedAccounts = [];
    for (const account of TEST_ACCOUNTS) {
        if (await loadOrCreateAccount(account)) {
            loadedAccounts.push(account);
        }
    }
    
    if (loadedAccounts.length < 2) {
        console.log('\n❌ Need at least 2 accounts to run tests');
        console.log('\nCreate accounts with:');
        console.log('  node scripts/setup_identity.js --name test1 --agent');
        console.log('  node scripts/setup_identity.js --name test2 --agent');
        return;
    }
    
    console.log(`\n✅ Loaded ${loadedAccounts.length} account(s)`);
    
    // Test 1: Check inbox for each account
    console.log('\n' + '='.repeat(60));
    console.log('Test 1: Check Inboxes');
    console.log('='.repeat(60));
    
    for (const account of loadedAccounts) {
        await checkInbox(account);
    }
    
    // Test 2: Send messages between accounts
    console.log('\n' + '='.repeat(60));
    console.log('Test 2: Send Messages (All Pairs)');
    console.log('='.repeat(60));
    
    for (let i = 0; i < loadedAccounts.length; i++) {
        for (let j = 0; j < loadedAccounts.length; j++) {
            if (i !== j) {
                const from = loadedAccounts[i];
                const to = loadedAccounts[j];
                const content = `Test message from ${from.name} to ${to.name} @ ${new Date().toISOString()}`;
                
                try {
                    await sendMessage(from, to, content);
                } catch (e) {
                    console.log(`Failed: ${from.name} -> ${to.name}: ${e.message}`);
                }
                
                // Small delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        }
    }
    
    // Test 3: Check inboxes again
    console.log('\n' + '='.repeat(60));
    console.log('Test 3: Check Inboxes After Sending');
    console.log('='.repeat(60));
    
    for (const account of loadedAccounts) {
        await checkInbox(account);
    }
    
    // Summary
    console.log('\n' + '='.repeat(60));
    console.log('Test Summary');
    console.log('='.repeat(60));
    console.log(`Accounts: ${loadedAccounts.length}`);
    console.log(`Messages sent: ${loadedAccounts.length * (loadedAccounts.length - 1)}`);
    console.log('='.repeat(60));
}

// Run tests
runTests().catch(console.error);
