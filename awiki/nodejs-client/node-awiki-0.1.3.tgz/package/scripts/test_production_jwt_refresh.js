#!/usr/bin/env node

/**
 * Production mode test: Send message with auto JWT refresh.
 * 
 * Usage:
 *   node scripts/test_production_jwt_refresh.js <credential_name>
 * 
 * Example:
 *   node scripts/test_production_jwt_refresh.js apitest1
 */

import { loadIdentity, createAuthenticator } from '../src/credential_store.js';
import { createSDKConfig } from '../src/utils/config.js';
import { createMoltMessageClient } from '../src/utils/client.js';
import { authenticatedRpcCall } from '../src/utils/rpc.js';

const credentialName = process.argv[2] || 'apitest1';

async function testProductionJwtRefresh() {
    console.log('='.repeat(60));
    console.log('Production Mode: JWT Auto-Refresh Test');
    console.log('='.repeat(60));
    console.log(`Credential: ${credentialName}`);
    console.log(`Mode: PRODUCTION (system credentials)`);
    console.log('='.repeat(60));
    
    // Load identity
    console.log(`\nLoading identity: ${credentialName}...`);
    const identity = loadIdentity(credentialName);
    
    if (!identity) {
        console.log(`❌ Identity '${credentialName}' not found.`);
        console.log(`\nAvailable identities:`);
        console.log(`  Check: C:\\Users\\hyg\\.openclaw\\credentials\\awiki-agent-id-message\\index.json`);
        return;
    }
    
    console.log(`✅ Loaded: ${identity.did}`);
    
    // Check JWT
    const jwt = identity.jwt_token;
    if (!jwt) {
        console.log(`⚠️  No JWT token found, will obtain one.`);
    } else {
        // Check JWT expiration
        try {
            const jwtParts = jwt.split('.');
            const payload = JSON.parse(Buffer.from(jwtParts[1], 'base64').toString());
            const expTime = new Date(payload.exp * 1000);
            const now = new Date();
            const expiresIn = Math.round((expTime - now) / 1000 / 60);
            
            console.log(`JWT Expires: ${expTime.toISOString()}`);
            
            if (expTime < now) {
                console.log(`⚠️  JWT EXPIRED ${Math.abs(expiresIn)} minutes ago`);
                console.log(`   Auto-refresh will be tested.`);
            } else {
                console.log(`✅ JWT valid for ${expiresIn} minutes`);
                console.log(`   To test auto-refresh, wait for JWT to expire or modify auth.json`);
            }
        } catch (e) {
            console.log(`⚠️  Could not check JWT expiration: ${e.message}`);
        }
    }
    
    // Create authenticator
    console.log(`\nCreating authenticator...`);
    const config = createSDKConfig();
    const authResult = await createAuthenticator(credentialName, config);
    
    if (!authResult) {
        console.log(`❌ Failed to create authenticator.`);
        return;
    }
    
    const { auth } = authResult;
    console.log(`✅ Authenticator created.`);
    
    // Send message
    console.log(`\nSending message...`);
    const client = createMoltMessageClient(config);
    
    const messageContent = `Production test @ ${new Date().toISOString()}`;
    const targetDid = identity.did; // Send to self for testing
    
    try {
        const result = await authenticatedRpcCall(
            client,
            '/message/rpc',
            'send',
            {
                sender_did: identity.did,
                receiver_did: targetDid,
                content: messageContent,
                type: 'text',
                client_msg_id: `prod_test_${Date.now()}`
            },
            1,
            { auth, credentialName }
        );
        
        console.log(`\n✅ Message sent successfully!`);
        console.log(`   Server Seq: ${result.server_seq}`);
        console.log(`   Message ID: ${result.id}`);
        
        // Verify JWT was updated
        const updatedIdentity = loadIdentity(credentialName);
        if (updatedIdentity && updatedIdentity.jwt_token && updatedIdentity.jwt_token !== jwt) {
            console.log(`\n✅ JWT was refreshed!`);
            
            // Check new JWT expiration
            try {
                const newJwtParts = updatedIdentity.jwt_token.split('.');
                const newPayload = JSON.parse(Buffer.from(newJwtParts[1], 'base64').toString());
                const newExpTime = new Date(newPayload.exp * 1000);
                const now = new Date();
                const newExpiresIn = Math.round((newExpTime - now) / 1000 / 60);
                console.log(`   New JWT expires: ${newExpTime.toISOString()}`);
                console.log(`   New JWT valid for: ${newExpiresIn} minutes`);
            } catch (e) {
                console.log(`⚠️  Could not check new JWT expiration: ${e.message}`);
            }
        } else {
            console.log(`\nℹ️  JWT was not updated (may still be valid)`);
        }
        
    } catch (e) {
        console.log(`\n❌ Failed: ${e.message}`);
        
        if (e.message.includes('401')) {
            console.log(`\n   JWT refresh may have failed.`);
        }
        
        throw e;
    }
    
    console.log('\n' + '='.repeat(60));
    console.log('Test Complete');
    console.log('='.repeat(60));
}

// Run test
testProductionJwtRefresh().catch(console.error);
