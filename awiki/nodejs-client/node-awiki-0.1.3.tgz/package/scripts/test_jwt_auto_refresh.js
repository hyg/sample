#!/usr/bin/env node

/**
 * Test JWT auto-refresh mechanism.
 *
 * This test verifies that the Node.js implementation matches Python's behavior:
 * 1. Detect 401 Unauthorized
 * 2. Clear expired token
 * 3. Regenerate DID signature authentication
 * 4. Retry the request
 * 5. Save new JWT to credential file
 */

import { DIDWbaAuthHeader } from '../lib/anp/authentication/did_wba_authenticator.js';
import { loadIdentity, updateJwt } from './utils/credential_store.js';
import axios from 'axios';

const TEST_CREDENTIAL = 'test_jwt_refresh';
const SERVER_URL = 'https://awiki.ai';

/**
 * Test 1: Verify DIDWbaAuthHeader token caching
 */
async function testTokenCaching() {
    console.log('\n=== Test 1: Token Caching ===');

    const cred = loadIdentity(TEST_CREDENTIAL);
    if (!cred) {
        console.log('SKIP: No test credential found. Please run setup_identity first.');
        return false;
    }

    // Create auth header instance with file paths
    const credDir = process.env.USERPROFILE + '/.openclaw/credentials/awiki-agent-id-message';
    const didDocPath = `${credDir}/${cred.did.split(':').pop()}/did.json`;
    const privateKeyPath = `${credDir}/${cred.did.split(':').pop()}/key-1_private.pem`;

    const auth = new DIDWbaAuthHeader(didDocPath, privateKeyPath);

    // First call - should generate DID auth header
    const headers1 = auth.getAuthHeader(SERVER_URL);
    console.log('First call (DID auth):', headers1.Authorization.substring(0, 50) + '...');

    // Simulate receiving a token
    auth.updateToken(SERVER_URL, { Authorization: 'Bearer test_token_123' });

    // Second call - should use cached token
    const headers2 = auth.getAuthHeader(SERVER_URL);
    console.log('Second call (cached token):', headers2.Authorization);

    if (headers2.Authorization === 'Bearer test_token_123') {
        console.log('✓ PASS: Token caching works');
        return true;
    } else {
        console.log('✗ FAIL: Token caching failed');
        return false;
    }
}

/**
 * Test 2: Verify 401 retry mechanism
 */
async function test401Retry() {
    console.log('\n=== Test 2: 401 Retry Mechanism ===');

    const cred = loadIdentity(TEST_CREDENTIAL);
    if (!cred) {
        console.log('SKIP: No test credential found.');
        return false;
    }

    const credDir = process.env.USERPROFILE + '/.openclaw/credentials/awiki-agent-id-message';
    const didDocPath = `${credDir}/${cred.did.split(':').pop()}/did.json`;
    const privateKeyPath = `${credDir}/${cred.did.split(':').pop()}/key-1_private.pem`;

    const auth = new DIDWbaAuthHeader(didDocPath, privateKeyPath);

    // Simulate cached token
    auth.updateToken(SERVER_URL, { Authorization: 'Bearer expired_token' });

    // First call - should use cached (expired) token
    const headers1 = auth.getAuthHeader(SERVER_URL);
    console.log('Before 401:', headers1.Authorization);

    // Simulate 401 response
    auth.clearToken(SERVER_URL);

    // Second call with force_new - should generate new DID auth
    const headers2 = auth.getAuthHeader(SERVER_URL, true);
    console.log('After 401 (force new):', headers2.Authorization.substring(0, 50) + '...');

    if (headers2.Authorization.startsWith('DIDWba')) {
        console.log('✓ PASS: 401 retry mechanism works');
        return true;
    } else {
        console.log('✗ FAIL: 401 retry mechanism failed');
        return false;
    }
}

/**
 * Test 3: Verify JWT persistence
 */
async function testJwtPersistence() {
    console.log('\n=== Test 3: JWT Persistence ===');

    const cred = loadIdentity(TEST_CREDENTIAL);
    if (!cred) {
        console.log('SKIP: No test credential found.');
        return false;
    }

    const oldToken = cred.jwt_token;
    const newToken = 'new_test_jwt_token_xyz';

    // Update JWT
    updateJwt(TEST_CREDENTIAL, newToken);

    // Reload and verify
    const updatedCred = loadIdentity(TEST_CREDENTIAL);
    console.log('Old token:', oldToken ? oldToken.substring(0, 30) + '...' : 'none');
    console.log('New token:', updatedCred.jwt_token ? updatedCred.jwt_token.substring(0, 30) + '...' : 'none');

    if (updatedCred.jwt_token === newToken) {
        console.log('✓ PASS: JWT persistence works');
        // Restore old token
        updateJwt(TEST_CREDENTIAL, oldToken);
        return true;
    } else {
        console.log('✗ FAIL: JWT persistence failed');
        return false;
    }
}

/**
 * Main test runner
 */
async function runTests() {
    console.log('=================================');
    console.log('JWT Auto-Refresh Test Suite');
    console.log('=================================');

    const results = {
        tokenCaching: await testTokenCaching(),
        retry401: await test401Retry(),
        persistence: await testJwtPersistence()
    };

    console.log('\n=================================');
    console.log('Test Results');
    console.log('=================================');
    console.log(`Token Caching:      ${results.tokenCaching ? '✓ PASS' : '✗ FAIL'}`);
    console.log(`401 Retry:          ${results.retry401 ? '✓ PASS' : '✗ FAIL'}`);
    console.log(`JWT Persistence:    ${results.persistence ? '✓ PASS' : '✗ FAIL'}`);

    const passCount = Object.values(results).filter(r => r).length;
    const totalCount = Object.keys(results).length;

    console.log(`\nTotal: ${passCount}/${totalCount} tests passed`);

    if (passCount === totalCount) {
        console.log('\n✓ All tests passed! JWT auto-refresh mechanism is working correctly.');
    } else {
        console.log('\n✗ Some tests failed. Please review the implementation.');
    }

    return passCount === totalCount;
}

// Run tests
runTests().catch(error => {
    console.error('Test suite error:', error);
    process.exit(1);
});
