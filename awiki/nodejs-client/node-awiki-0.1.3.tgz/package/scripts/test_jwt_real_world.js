#!/usr/bin/env node

/**
 * Real-World Test: JWT Auto-Refresh with Actual Credentials
 * 
 * This test uses real credentials to verify the complete JWT auto-refresh flow:
 * 1. Load existing credential with JWT
 * 2. Make API call with cached JWT
 * 3. Simulate JWT expiration (by clearing cache)
 * 4. Verify automatic re-authentication
 * 5. Verify new JWT is saved to credential file
 */

import { DIDWbaAuthHeader } from '../lib/anp/authentication/did_wba_authenticator.js';
import { loadIdentity, updateJwt, getCredentialPath } from './utils/credential_store.js';
import { createSDKConfig } from './utils/config.js';
import { authenticatedRpcCall } from './utils/rpc.js';
import axios from 'axios';
import { readFileSync, writeFileSync } from 'fs';

const TEST_CREDENTIALS = [
    'k1_mDyUh8K5Kvy9-yLw4hocM2Vue5lj9VBjZE-TnqY51W0'  // jwt_test
];

const SERVER_URL = 'https://awiki.ai';
const USER_SERVICE_RPC = '/user-service/did-auth/rpc';

/**
 * Test: Get user info with auto-refresh
 */
async function testGetMeWithAutoRefresh(credentialName) {
    console.log(`\n=== Testing with credential: ${credentialName} ===`);
    
    try {
        // Load credential
        const cred = loadIdentity(credentialName);
        
        if (!cred) {
            console.log(`SKIP: Credential '${credentialName}' not found`);
            return { skipped: true };
        }
        
        console.log(`DID: ${cred.did}`);
        console.log(`JWT: ${cred.jwt_token ? cred.jwt_token.substring(0, 30) + '...' : 'MISSING'}`);
        
        if (!cred.jwt_token) {
            console.log('SKIP: No JWT token in credential');
            return { skipped: true };
        }
        
        // Create auth header instance
        const credDir = getCredentialPath(credentialName).replace(/\\/g, '/').split('/').slice(0, -1).join('/');
        const didName = cred.did.split(':').pop();
        const didDocPath = `${credDir}/${didName}/did.json`;
        const privateKeyPath = `${credDir}/${didName}/key-1_private.pem`;
        
        let auth;
        try {
            auth = new DIDWbaAuthHeader(didDocPath, privateKeyPath);
        } catch (e) {
            console.log('SKIP: Cannot load DID document or private key');
            return { skipped: true };
        }
        
        // Pre-populate with existing JWT
        auth.tokens['awiki.ai'] = cred.jwt_token;
        
        // Create HTTP client
        const client = axios.create({
            baseURL: SERVER_URL,
            headers: { 'Content-Type': 'application/json' }
        });
        
        // Test 1: Make API call with cached JWT
        console.log('\nTest 1: API call with cached JWT');
        try {
            const result1 = await authenticatedRpcCall(
                client,
                USER_SERVICE_RPC,
                'get_me',
                {},
                1,
                { auth, credentialName, updateJwtCallback: updateJwt }
            );
            
            console.log(`✓ SUCCESS: get_me returned user_id: ${result1.user_id}`);
            
            // Verify JWT was used
            const credAfter = loadIdentity(credentialName);
            if (credAfter.jwt_token === cred.jwt_token) {
                console.log('✓ JWT preserved in credential file');
            }
            
        } catch (error) {
            console.log(`✗ FAILED: ${error.message}`);
            return { success: false, error: error.message };
        }
        
        // Test 2: Simulate JWT expiration and verify auto-refresh
        console.log('\nTest 2: Simulate JWT expiration and auto-refresh');
        
        // Clear cached token (simulating 401 response)
        auth.clearToken(SERVER_URL);
        console.log('Cleared cached token (simulating 401)');
        
        try {
            // This should trigger DID re-authentication
            const result2 = await authenticatedRpcCall(
                client,
                USER_SERVICE_RPC,
                'get_me',
                {},
                1,
                { auth, credentialName, updateJwtCallback: updateJwt }
            );
            
            console.log(`✓ SUCCESS: Auto-refresh worked, user_id: ${result2.user_id}`);
            
            // Verify new JWT was saved
            const credAfter = loadIdentity(credentialName);
            if (credAfter.jwt_token && credAfter.jwt_token !== cred.jwt_token) {
                console.log('✓ New JWT saved to credential file');
            } else if (credAfter.jwt_token === cred.jwt_token) {
                console.log('✓ JWT unchanged (still valid)');
            } else {
                console.log('✗ JWT not saved correctly');
            }
            
            return { success: true };
            
        } catch (error) {
            console.log(`✗ FAILED: Auto-refresh failed - ${error.message}`);
            return { success: false, error: error.message };
        }
        
    } catch (error) {
        console.log(`✗ ERROR: ${error.message}`);
        return { success: false, error: error.message };
    }
}

/**
 * Main test runner
 */
async function runRealWorldTests() {
    console.log('=================================');
    console.log('Real-World JWT Auto-Refresh Test');
    console.log('=================================');
    console.log(`Date: ${new Date().toISOString()}`);
    console.log(`Server: ${SERVER_URL}`);
    
    const results = [];
    
    for (const credName of TEST_CREDENTIALS) {
        const result = await testGetMeWithAutoRefresh(credName);
        results.push({ credential: credName, ...result });
        
        // Wait between tests
        if (credName !== TEST_CREDENTIALS[TEST_CREDENTIALS.length - 1]) {
            console.log('\n--- Waiting 2 seconds ---\n');
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }
    
    // Summary
    console.log('\n=================================');
    console.log('Test Summary');
    console.log('=================================');
    
    const successCount = results.filter(r => r.success).length;
    const skipCount = results.filter(r => r.skipped).length;
    const failCount = results.filter(r => !r.success && !r.skipped).length;
    
    console.log(`Total:  ${results.length}`);
    console.log(`Success: ${successCount}`);
    console.log(`Skipped: ${skipCount}`);
    console.log(`Failed: ${failCount}`);
    
    if (failCount === 0 && successCount > 0) {
        console.log('\n✓ All real-world tests passed!');
        console.log('JWT auto-refresh mechanism is working correctly with actual credentials.');
        return true;
    } else if (successCount === 0 && skipCount > 0) {
        console.log('\n⚠ All tests skipped (no valid credentials found)');
        console.log('Please create credentials first with setup_identity.js');
        return null;
    } else {
        console.log('\n✗ Some tests failed.');
        return false;
    }
}

// Run tests
runRealWorldTests()
    .then(success => {
        if (success === null) {
            process.exit(0); // Skipped is OK
        }
        process.exit(success ? 0 : 1);
    })
    .catch(error => {
        console.error('Test suite error:', error);
        process.exit(1);
    });
