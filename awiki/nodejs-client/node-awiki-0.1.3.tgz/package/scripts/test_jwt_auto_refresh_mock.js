#!/usr/bin/env node

/**
 * Test JWT auto-refresh mechanism (mock version).
 */

import { DIDWbaAuthHeader } from '../lib/anp/authentication/did_wba_authenticator.js';

const SERVER_URL = 'https://awiki.ai';

/**
 * Test 1: Verify token caching
 */
async function testTokenCaching() {
    console.log('\n=== Test 1: Token Caching ===');

    // Create a mock auth instance
    const auth = new DIDWbaAuthHeader(null, null);

    // Manually set a token
    auth.tokens['awiki.ai'] = 'test_token_123';

    // First call - should use cached token
    const headers1 = auth.getAuthHeader(SERVER_URL);
    console.log('With cached token:', headers1.Authorization);

    if (headers1.Authorization === 'Bearer test_token_123') {
        console.log('✓ PASS: Token caching works');
        return true;
    } else {
        console.log('✗ FAIL: Token caching failed');
        return false;
    }
}

/**
 * Test 2: Verify 401 retry mechanism
 */
async function test401Retry() {
    console.log('\n=== Test 2: 401 Retry Mechanism ===');

    const auth = new DIDWbaAuthHeader(null, null);

    // Set cached token
    auth.tokens['awiki.ai'] = 'expired_token';

    // First call - should use cached token
    const headers1 = auth.getAuthHeader(SERVER_URL);
    console.log('Before clear:', headers1.Authorization);

    // Simulate 401 - clear token
    auth.clearToken(SERVER_URL);

    // Check token is cleared
    if (!('awiki.ai' in auth.tokens)) {
        console.log('✓ Token cleared successfully');
    } else {
        console.log('✗ Token clear failed');
        return false;
    }

    // After clear, should generate DID auth (but will fail without proper setup)
    // For this test, we just verify the token is cleared
    console.log('✓ PASS: 401 retry mechanism (token clear) works');
    return true;
}

/**
 * Test 3: Verify token update
 */
async function testTokenUpdate() {
    console.log('\n=== Test 3: Token Update ===');

    const auth = new DIDWbaAuthHeader(null, null);

    // Simulate response with new token
    const headers = { Authorization: 'Bearer new_token_xyz' };
    const token = auth.updateToken(SERVER_URL, headers);

    console.log('Received token:', token);

    if (token === 'new_token_xyz' && auth.tokens['awiki.ai'] === 'new_token_xyz') {
        console.log('✓ PASS: Token update works');
        return true;
    } else {
        console.log('✗ FAIL: Token update failed');
        return false;
    }
}

/**
 * Main test runner
 */
async function runTests() {
    console.log('=================================');
    console.log('JWT Auto-Refresh Test Suite (Mock)');
    console.log('=================================');

    const results = {
        tokenCaching: await testTokenCaching(),
        retry401: await test401Retry(),
        tokenUpdate: await testTokenUpdate()
    };

    console.log('\n=================================');
    console.log('Test Results');
    console.log('=================================');
    console.log(`Token Caching:      ${results.tokenCaching ? '✓ PASS' : '✗ FAIL'}`);
    console.log(`401 Retry:          ${results.retry401 ? '✓ PASS' : '✗ FAIL'}`);
    console.log(`Token Update:       ${results.tokenUpdate ? '✓ PASS' : '✗ FAIL'}`);

    const passCount = Object.values(results).filter(r => r).length;
    const totalCount = Object.keys(results).length;

    console.log(`\nTotal: ${passCount}/${totalCount} tests passed`);

    if (passCount === totalCount) {
        console.log('\n✓ All core tests passed!');
        console.log('Note: Full integration test requires valid credentials.');
    }

    return passCount === totalCount;
}

// Run tests
runTests().catch(error => {
    console.error('Test suite error:', error);
    process.exit(1);
});
